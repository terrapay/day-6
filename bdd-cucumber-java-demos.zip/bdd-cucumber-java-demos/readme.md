# This is a comprehensive Tutorial to cover the Cucumber features
 - Maven dependencies
       
        <dependency>
        	<groupId>info.cukes</groupId>
        	<artifactId>cucumber-java</artifactId>
        	<version>1.2.5</version>
        	<scope>test</scope>
        </dependency>
        
        <dependency>
        	<groupId>info.cukes</groupId>
        	<artifactId>cucumber-junit</artifactId>
        	<version>1.2.5</version>
        	<scope>test</scope>
        </dependency>
# Gherkin Language

- Feature
- Scenario
- Scenario Outline
- Background
- Given
- When
- Then
- And
- But
- Datatable
- Doc Strings
- Gherkin Expressions
